# IDS EM TEMPO REAL COM THREADS - SOMATIVA 3

Sistema de Detecção de Intrusão (IDS) implementado em Python usando o modelo produtor-consumidor com threads para análise em tempo real de tráfego de rede a partir de arquivos PCAP.

## 📁 Estrutura do Projeto

```
ids_project/
├── somativa3.py              # ⭐ Código final (versão 2B - melhor implementação)
├── somativa_1a.py            # Parte 1A: sem lock (race condition)
├── somativa_1b.py            # Parte 1B: single lock global
├── somativa_1c.py            # Parte 1C: locks individuais
├── somativa_2a.py            # Parte 2A: alertas em tempo real sem lock completo
├── somativa_2b.py            # Parte 2B: alertas em tempo real com lock completo
├── myscapyLib.py             # Biblioteca de funções Scapy
├── desafio.pcap              # Arquivo de captura de pacotes
├── executar_todos.py         # Script para executar todas as versões
├── RELATORIO.md              # Relatório completo da somativa
├── README.md                 # Este arquivo
└── alerta_*.txt              # Arquivos de alertas gerados
```

## 🎯 Objetivos do Projeto

### Parte 1: Condição de Corrida
- Demonstrar problemas de race condition em contadores compartilhados
- Comparar diferentes estratégias de sincronização (sem lock, single lock, locks individuais)
- Analisar trade-offs entre consistência e desempenho

### Parte 2: Alertas em Tempo Real
- Implementar detecção de ataques em tempo real (ICMP Flood, SYN Flood, Port Scan)
- Demonstrar a importância de seções críticas completas
- Resolver problemas de race condition na verificação e zeragem de contadores

## 🚀 Como Usar

### Requisitos

```bash
# Instalar Python 3.x
sudo apt-get install python3

# Instalar Scapy
pip install scapy --break-system-packages
```

### Execução Rápida (Versão Final)

```bash
python3 somativa3.py
```

O arquivo `alerta.txt` será gerado com os alertas detectados.

### Executar Todas as Versões

```bash
python3 executar_todos.py
```

Este script irá:
- Executar as versões 1A, 1B, 1C (3 vezes cada)
- Executar as versões 2A e 2B (1 vez cada)
- Gerar arquivos `alerta_1a.txt`, `alerta_1b.txt`, etc.

### Execução Manual

```bash
# Parte 1A - Sem lock (3 execuções)
python3 somativa_1a.py
python3 somativa_1a.py
python3 somativa_1a.py
cp alerta.txt alerta_1a.txt

# Parte 1B - Single lock (3 execuções)
rm alerta.txt
python3 somativa_1b.py
python3 somativa_1b.py
python3 somativa_1b.py
cp alerta.txt alerta_1b.txt

# Parte 1C - Locks individuais (3 execuções)
rm alerta.txt
python3 somativa_1c.py
python3 somativa_1c.py
python3 somativa_1c.py
cp alerta.txt alerta_1c.txt

# Parte 2A - Alertas sem lock completo (1 execução)
rm alerta.txt
python3 somativa_2a.py
cp alerta.txt alerta_2a.txt

# Parte 2B - Alertas com lock completo (1 execução)
rm alerta.txt
python3 somativa_2b.py
cp alerta.txt alerta_2b.txt
```

## 🔍 Tipos de Ataques Detectados

O sistema detecta três tipos principais de ataques DoS/DDoS:

### 1. ICMP Flood
- **Origem:** Detecta IPs enviando muitos pacotes ICMP (ping flood)
- **Destino:** Detecta IPs recebendo muitos pacotes ICMP (vítima)
- **Limite:** 100 pacotes

### 2. SYN Flood
- **Origem:** Detecta IPs enviando muitos pacotes TCP SYN (ataque)
- **Destino:** Detecta IPs recebendo muitos pacotes TCP SYN (vítima)
- **Limite:** 100 pacotes

### 3. Port Scan
- **Origem:** Detecta IPs tentando conectar em muitas portas diferentes
- **Limite:** 50 portas distintas

## ⚙️ Configuração

Você pode ajustar os parâmetros no início dos arquivos `.py`:

```python
ARQUIVO = "desafio.pcap"      # Arquivo PCAP a analisar
N_WORKERS = 4                 # Número de threads workers
LIMITE_ICMP = 100             # Limite de pacotes ICMP
LIMITE_SYN = 100              # Limite de pacotes SYN
LIMITE_PORTSCAN = 50          # Limite de portas diferentes
ATRASO_RACE = 0.00001         # Atraso para forçar race condition (demo)
```

## 📊 Resultados Esperados

### Parte 1A (Sem Lock)
- ❌ Contadores **inconsistentes** entre execuções
- ✅ Desempenho bom (0 alertas de fila cheia)
- Demonstra race condition

### Parte 1B (Single Lock)
- ✅ Contadores **consistentes**
- ❌ Desempenho ruim (~8 alertas de fila cheia)
- Demonstra serialização excessiva

### Parte 1C (Locks Individuais)
- ✅ Contadores **consistentes**
- ✅ Desempenho bom (0 alertas de fila cheia)
- **Melhor solução da Parte 1**

### Parte 2A (Alertas sem Lock Completo)
- ❌ Alertas **duplicados** e **inconsistentes**
- ❌ ~51 alertas (muitos falsos positivos)
- Demonstra race condition na verificação/zeragem

### Parte 2B (Alertas com Lock Completo)
- ✅ Alertas **corretos** e **consistentes**
- ✅ ~47 alertas (número adequado)
- **Melhor solução da Parte 2**

## 🏆 Melhor Implementação

**`somativa3.py` (versão 2B)** é a implementação final recomendada:

- Usa locks individuais por contador (granularidade adequada)
- Seções críticas completas (incremento + verificação + zeragem)
- Alertas em tempo real pelos workers
- Paralelismo eficiente sem race conditions

## 📖 Conceitos Demonstrados

1. **Produtor-Consumidor:** Padrão de design com fila compartilhada
2. **Race Conditions:** Problemas de concorrência em dados compartilhados
3. **Locks (Mutex):** Mecanismos de sincronização
4. **Granularidade de Locks:** Trade-off entre proteção e paralelismo
5. **Seções Críticas:** Definição correta do escopo de proteção
6. **Threading em Python:** `Thread`, `Lock`, `Queue`

## 📝 Relatório

Consulte `RELATORIO.md` para:
- Análise detalhada de cada versão
- Comparação de resultados
- Explicação dos problemas encontrados
- Justificativa das soluções implementadas

## 🐛 Troubleshooting

### Erro: ModuleNotFoundError: No module named 'scapy'
```bash
pip install scapy --break-system-packages
```

### Erro: Permission denied
```bash
chmod +x executar_todos.py
```

### Fila cheia aparecendo
Isso é esperado na versão 1B (single lock) devido à serialização. Nas outras versões, indica problema de desempenho.

### Alertas não são gerados
Verifique se:
- O arquivo `desafio.pcap` está no mesmo diretório
- O arquivo contém tráfego suficiente para ultrapassar os limites

## 📚 Referências

- [Scapy Documentation](https://scapy.readthedocs.io/)
- [Python Threading](https://docs.python.org/3/library/threading.html)
- [Producer-Consumer Pattern](https://en.wikipedia.org/wiki/Producer%E2%80%93consumer_problem)

## 👤 Autor

Projeto desenvolvido para Somativa 3 - IDS em Tempo Real com Threads

## 📄 Licença

Este projeto é para fins educacionais.

---

**Boa sorte! 🚀**
