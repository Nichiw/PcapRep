#!/usr/bin/env python3
"""
Script auxiliar para executar todas as versões do somativa3.py
Autor: Projeto IDS com Threads
Data: Maio 2026
"""

import os
import subprocess
import sys

def executar_versao(nome, arquivo, repeticoes=3):
    """Executa uma versão específica do código"""
    print(f"\n{'='*60}")
    print(f"EXECUTANDO: {nome}")
    print(f"Arquivo: {arquivo}")
    print(f"Repetições: {repeticoes}")
    print('='*60)
    
    # Remove arquivo de alertas anterior
    if os.path.exists('alerta.txt'):
        os.remove('alerta.txt')
    
    for i in range(1, repeticoes + 1):
        print(f"\n--- Rodada {i} ---")
        try:
            resultado = subprocess.run(
                [sys.executable, arquivo],
                capture_output=True,
                text=True,
                timeout=30
            )
            print(resultado.stdout)
            if resultado.stderr:
                print(f"Erros: {resultado.stderr}")
        except subprocess.TimeoutExpired:
            print(f"⚠️ Timeout na rodada {i}")
        except Exception as e:
            print(f"❌ Erro na rodada {i}: {e}")
    
    # Salva arquivo de alertas
    if os.path.exists('alerta.txt'):
        arquivo_final = f'alerta_{nome}.txt'
        os.rename('alerta.txt', arquivo_final)
        print(f"\n✅ Alertas salvos em: {arquivo_final}")
        
        # Mostra estatísticas
        with open(arquivo_final, 'r') as f:
            linhas = f.readlines()
            print(f"Total de alertas: {len(linhas)}")
    else:
        print("⚠️ Nenhum alerta foi gerado")

def main():
    """Executa todas as versões"""
    print("""
╔══════════════════════════════════════════════════════════════╗
║           IDS EM TEMPO REAL COM THREADS                      ║
║           Script de Execução Automática                      ║
╚══════════════════════════════════════════════════════════════╝
    """)
    
    # Verifica se estamos no diretório correto
    if not os.path.exists('desafio.pcap'):
        print("❌ ERRO: desafio.pcap não encontrado!")
        print("Execute este script no diretório do projeto")
        sys.exit(1)
    
    versoes = [
        ("1a", "somativa_1a.py", 3, "Sem lock (condição de corrida)"),
        ("1b", "somativa_1b.py", 3, "Single lock global"),
        ("1c", "somativa_1c.py", 3, "Locks individuais por contador"),
        ("2a", "somativa_2a.py", 1, "Alertas em tempo real SEM lock na verificação"),
        ("2b", "somativa_2b.py", 1, "Alertas em tempo real COM lock na verificação"),
    ]
    
    print("\nVersões disponíveis:")
    for i, (codigo, arquivo, reps, desc) in enumerate(versoes, 1):
        print(f"{i}. [{codigo}] {desc}")
        print(f"   Arquivo: {arquivo} | Repetições: {reps}")
    
    print("\nOpções:")
    print("  [Enter] - Executar TODAS as versões")
    print("  [1-5]   - Executar versão específica")
    print("  [q]     - Sair")
    
    escolha = input("\nEscolha: ").strip()
    
    if escolha.lower() == 'q':
        print("Saindo...")
        sys.exit(0)
    elif escolha == '':
        # Executar todas
        for codigo, arquivo, reps, desc in versoes:
            if os.path.exists(arquivo):
                executar_versao(codigo, arquivo, reps)
            else:
                print(f"\n⚠️ {arquivo} não encontrado, pulando...")
    elif escolha.isdigit() and 1 <= int(escolha) <= len(versoes):
        # Executar versão específica
        idx = int(escolha) - 1
        codigo, arquivo, reps, desc = versoes[idx]
        if os.path.exists(arquivo):
            executar_versao(codigo, arquivo, reps)
        else:
            print(f"\n❌ {arquivo} não encontrado!")
    else:
        print("❌ Opção inválida!")
        sys.exit(1)
    
    print(f"\n{'='*60}")
    print("✅ EXECUÇÃO CONCLUÍDA")
    print('='*60)
    print("\nArquivos gerados:")
    for f in os.listdir('.'):
        if f.startswith('alerta_') and f.endswith('.txt'):
            tamanho = os.path.getsize(f)
            print(f"  📄 {f} ({tamanho} bytes)")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️ Execução interrompida pelo usuário")
        sys.exit(0)
